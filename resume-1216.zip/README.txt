A Pen created at CodePen.io. You can find this one at https://codepen.io/chiu945/pen/MZWKQp.

 